CREATE DATABASE calimacil_android;
CREATE USER 'cali_db_usr'@'localhost' IDENTIFIED BY 'asfa43fs42rtwsd';
GRANT ALL ON calimacil_android.* TO 'cali_db_usr'@'%';
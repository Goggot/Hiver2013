<?php

class Connection {
	private static $connection;
	
	public static function getConnection() {
		if(!isset(Connection::$connection)) {
			Connection:$connection = new PDO("mysql:dbname=calimacil_android;host=localhost", "cali_db_usr", "asfa43fs42rtwsd");
		}
		return $connection;
	}
	
	public static function closeConnection() {
		Connection::$connection = null;
	}
}